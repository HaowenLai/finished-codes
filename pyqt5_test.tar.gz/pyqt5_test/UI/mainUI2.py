# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'UI/mainUI2.ui'
#
# Created by: PyQt5 UI code generator 5.12.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
  def setupUi(self, MainWindow):
    MainWindow.setObjectName("MainWindow")
    MainWindow.resize(640, 480)
    self.centralwidget = QtWidgets.QWidget(MainWindow)
    self.centralwidget.setObjectName("centralwidget")
    self.horizontalSlider = QtWidgets.QSlider(self.centralwidget)
    self.horizontalSlider.setGeometry(QtCore.QRect(140, 340, 331, 21))
    self.horizontalSlider.setAcceptDrops(False)
    self.horizontalSlider.setSliderPosition(0)
    self.horizontalSlider.setTracking(False)
    self.horizontalSlider.setOrientation(QtCore.Qt.Horizontal)
    self.horizontalSlider.setInvertedAppearance(False)
    self.horizontalSlider.setInvertedControls(False)
    self.horizontalSlider.setTickPosition(QtWidgets.QSlider.TicksBelow)
    self.horizontalSlider.setTickInterval(5)
    self.horizontalSlider.setObjectName("horizontalSlider")
    self.lb_imgDisplay = QtWidgets.QLabel(self.centralwidget)
    self.lb_imgDisplay.setGeometry(QtCore.QRect(250, 180, 111, 101))
    self.lb_imgDisplay.setFrameShape(QtWidgets.QFrame.NoFrame)
    self.lb_imgDisplay.setFrameShadow(QtWidgets.QFrame.Plain)
    self.lb_imgDisplay.setText("")
    self.lb_imgDisplay.setTextFormat(QtCore.Qt.AutoText)
    self.lb_imgDisplay.setPixmap(QtGui.QPixmap(":/vol/1.jpg"))
    self.lb_imgDisplay.setOpenExternalLinks(False)
    self.lb_imgDisplay.setTextInteractionFlags(QtCore.Qt.NoTextInteraction)
    self.lb_imgDisplay.setObjectName("lb_imgDisplay")
    MainWindow.setCentralWidget(self.centralwidget)

    self.retranslateUi(MainWindow)
    self.horizontalSlider.sliderMoved['int'].connect(MainWindow.changeImg)
    QtCore.QMetaObject.connectSlotsByName(MainWindow)

  def retranslateUi(self, MainWindow):
    _translate = QtCore.QCoreApplication.translate
    MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))


import resource_rc
