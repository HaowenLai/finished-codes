#! /bin/bash

# Modify `SRC_UI`` and `DST_UI` to your own files
SRC_UI=(                   # *.ui
"UI/mainUI2.ui"
)
DST_UI=(                   # *.py
"UI/mainUI2.py"
)
indent=2                   # number of space as indention

compile_resource=1         # 0 for no and 1 for yes
SRC_RESOURCE=(
"resources/resource.qrc"   #*.qrc
)
DST_RESOURCE=(
"resources/resource_rc.py" #*.py
)


# -----------!! Do NOT edit the following part. !! -----------
if [ ${#SRC_UI[*]} -ne ${#DST_UI[*]} ]
then
    echo "File numbers of src_ui and dst_ui do not match!"
    exit
fi

for ((i=0;i<${#SRC_UI[*]};i++)) do
    pyuic5 ${SRC_UI[$i]} -o ${DST_UI[$i]} -i $indent
done

if [ $compile_resource -eq 1 ]
then
    for ((i=0;i<${#SRC_RESOURCE[*]};i++)) do
        pyrcc5 ${SRC_RESOURCE[$i]} -o ${DST_RESOURCE[$i]} -compress 9
    done
fi
