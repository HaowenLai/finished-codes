#! /usr/bin/python3

import sys  
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtCore import Qt

from UI.mainUI import Ui_MainWindow

class MyMainWindow(QMainWindow):
  def print_haha(self, e):
    print('hahaha!')
    print(e)
  
  def keyPressEvent(self, e):
    if e.key() == Qt.Key_Escape:
      self.close()


if __name__ == "__main__":
  app  = QApplication(sys.argv)
  form = MyMainWindow()  
  
  mywin = Ui_MainWindow()
  mywin.setupUi(form)
  
  form.show()
  sys.exit(app.exec_())

