#! /usr/bin/python3

import sys
sys.path.append('./resources')

from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap

from UI.mainUI2 import Ui_MainWindow

class MyMainWindow(QMainWindow):
  def refUiObject(self, UiObj):
    self.UiObj = UiObj

  def changeImg(self, value):
    if value < 20:
      self.UiObj.lb_imgDisplay.setPixmap(QPixmap(":/vol/1.jpg"))
    elif value < 50:
      self.UiObj.lb_imgDisplay.setPixmap(QPixmap(":/vol/2.jpg"))
    elif value < 80:
      self.UiObj.lb_imgDisplay.setPixmap(QPixmap(":/vol/3.jpg"))
    else:
      self.UiObj.lb_imgDisplay.setPixmap(QPixmap(":/vol/4.jpg"))
  
  def keyPressEvent(self, e):
    if e.key() == Qt.Key_Escape:
      self.close()


if __name__ == "__main__":
  app  = QApplication(sys.argv)
  form = MyMainWindow()  
  
  mywin = Ui_MainWindow()
  mywin.setupUi(form)
  form.refUiObject(mywin)
  
  form.show()
  sys.exit(app.exec_())

