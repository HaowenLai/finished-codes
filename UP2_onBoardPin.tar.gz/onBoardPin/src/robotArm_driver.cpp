/* ******************************************************
 * This is the driver of our Intel project "robotic arm"
 * @Author  : Derek Lai
 * @Date    : 2018/5/2
 * @Platform: ROS
 * @Device  : UP2 Squared
 * ******************************************************/

//ROS includes
#include <ros/ros.h>
#include <std_msgs/Empty.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include "ardrone_autonomy/Navdata.h"
#include <std_msgs/UInt32.h>

//standard includes
#include <iostream>
#include <string.h>
#include <time.h>

//opencv include
#include <opencv2/opencv.hpp>

//my own message
#include <my_uav/BodyResult.h>
#include <my_uav/RangeResult.h>
#include <my_uav/GestureResult.h>

