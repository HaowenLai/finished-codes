/* **************************************************************
 *                             _ooOoo_
 *                            o8888888o
 *                            88" . "88
 *                            (| -_- |)
 *                            O\  =  /O
 *                         ____/`---'\____
 *                       .'  \\|     |//  `.
 *                      /  \\|||  :  |||//  \
 *                     /  _||||| -:- |||||-  \
 *                     |   | \\\  -  /// |   |
 *                     | \_|  ''\---/''  |   |
 *                     \  .-\__  `-`  ___/-. /
 *                   ___`. .'  /--.--\  `. . __
 *                ."" '<  `.___\_<|>_/___.'  >'"".
 *               | | :  `- \`.;`\ _ /`;.`/ - ` : | |
 *               \  \ `-.   \_ __\ /__ _/   .-` /  /
 *          ======`-.____`-.___\_____/___.-`____.-'======
 *                             `=---='
 *          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 *                      佛祖保佑        永无BUG
 * *************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <poll.h>
#include <unistd.h>
#include "onBoardPin.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <termios.h>
#include <errno.h>

//class onBoardGPIO define
//-------------------------------------------------------
int onBoardGPIO::__export()
{
    char buffer[64];  
    int len;  
    int fd;  

    fd = open("/sys/class/gpio/export", O_WRONLY);

    if (fd < 0)
    {  
        printf("Failed to open export for writing!\n");
        return(-1);  
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", pinNum);  
    if (write(fd, buffer, len) < 0)
    {  
        printf("Failed to export gpio%d!\n",pinNum);  
        return -1;  
    }

    close(fd);
    return 0;
}

int onBoardGPIO::__unexport()
{
    char buffer[64];
    int len;
    int fd;

    fd = open("/sys/class/gpio/unexport", O_WRONLY);

    if (fd < 0)
    {
        printf("Failed to open unexport for writing!\n");
        return -1;
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", pinNum);
    if (write(fd, buffer, len) < 0)
    {
        printf("Failed to unexport gpio%d!\n",pinNum);
        return -1;
    }  

    close(fd);
    return 0;
}

//@param:
//      IN  set pin as input status
//      OUT set pin as output status
//@return:
//       0,success;  -1,fail
int onBoardGPIO::setDirection(int direction)
{
    static const char dir_str[] = "in\0out";
    char path[64];
    int fd;

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/direction", pinNum);
    fd = open(path, O_WRONLY);

    if (fd < 0)
    {
        printf("Failed to open gpio%d direction for writing!\n",pinNum);
        return -1;
    }  

    if (write(fd, &dir_str[direction == 0 ? 0 : 3], direction == 0 ? 2 : 3) < 0)
    {
        printf("Failed to set direction for pin%d!\n",pinNum);
        return -1;
    }  

    close(fd);
    return 0;
}

//@param:
//      NOT_INTERRUPT 表示引脚为输入，不是中断引脚
//      RISING        表示引脚为中断输入，上升沿触发
//      FALLING       表示引脚为中断输入，下降沿触发
//      BOTH          表示引脚为中断输入，边沿触发
//@return:
//      0,success; -1,fail
int onBoardGPIO::setEdge(int edge)
{
    const char dir_str[] = "none\0rising\0falling\0both"; 
    char ptr;
    char path[64];  
    int fd; 

    switch(edge)
    {
    case 0:
        ptr = 0;
        break;
    case 1:
        ptr = 5;
        break;
    case 2:
        ptr = 12;
        break;
    case 3:
        ptr = 20;
        break;
    default:
        ptr = 0;
    } 

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/edge", pinNum);  

    fd = open(path, O_WRONLY);

    if (fd < 0)
    {  
        printf("Failed to open gpio%d edge for writing!\n",pinNum);
        return -1;
    }  

    if (write(fd, &dir_str[ptr], strlen(&dir_str[ptr])) < 0)
    {
        printf("Failed to set edge for pin %d!\n",pinNum);
        return -1;
    }  

    close(fd);
    return 0;
}

//@param: None
//@return : the pin value
int onBoardGPIO::readValue()
{
    char path[64];
    char value_str[3];
    int fd;

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", pinNum);

    fd = open(path, O_RDONLY);

    if (fd < 0)
    {
        printf("Failed to open gpio%d value for reading!\n",pinNum);
        return -1;
    }  

    if (read(fd, value_str, 3) < 0)
    {
        printf("Failed to read value for pin %d!\n",pinNum);
        return -1;
    }  

    close(fd);
    return (atoi(value_str));
}

//@param
//  value: the value to be written
//@return:
//  0,success; -1,fail
int onBoardGPIO::writeValue(int value)
{
    static const char values_str[] = "01";
    char path[64];
    int fd;

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", pinNum);
    fd = open(path, O_WRONLY);

    if (fd < 0)
    {
        printf("Failed to open gpio%d value for writing!\n",pinNum);
        return -1;
    }  

    if (write(fd, &values_str[value == 0 ? 0 : 1], 1) < 0)
    {
        printf("Failed to write value for pin %d!\n",pinNum);
        return -1;
    }  

    close(fd);
    return 0;
}

onBoardGPIO::onBoardGPIO(int pinNumber,int direction)
{
    pinNum = pinNumber;

    if(__export())
        ;//exit(-1);
    if(setDirection(direction))
        ;//exit(-1);
}

onBoardGPIO::~onBoardGPIO()
{
    __unexport();
}

//END class onBoardGPIO define
//-------------------------------------------------------


//class onBoardUART define
//-------------------------------------------------------
int onBoardUART::setOption(int nSpeed,int nBits,char nEvent,int nStop)
{
    struct termios newtio,oldtio;
    if(tcgetattr(confd,&oldtio) != 0)
    {
        perror("SetupSerial 1");
        return -1;
    }
    bzero(&newtio,sizeof(newtio));
    newtio.c_cflag |= CLOCAL|CREAD;
    newtio.c_cflag &= ~CSIZE;

    switch(nBits)
    {
    case 7:
        newtio.c_cflag |=CS7;
        break;
    case 8:
        newtio.c_cflag |=CS8;
        break;
    }

    switch(nEvent)
    {
    case 'O':
        newtio.c_cflag |= PARENB;
        newtio.c_cflag |= PARODD;
        newtio.c_iflag |= (INPCK|ISTRIP);
        break;
    case 'E':
        newtio.c_cflag |= PARENB;
        newtio.c_cflag &= ~PARODD;
        newtio.c_iflag |= (INPCK|ISTRIP);
        break;
    case 'N':
        newtio.c_cflag &= ~PARENB;
        break;
    }

    switch(nSpeed)
    {
    case 2400:
        cfsetispeed(&newtio,B2400);
        cfsetospeed(&newtio,B2400);
        break;
    case 4800:
        cfsetispeed(&newtio,B4800);
        cfsetospeed(&newtio,B4800);
        break;
    case 9600:
        cfsetispeed(&newtio,B9600);
        cfsetospeed(&newtio,B9600);
        break;
    case 115200:
        cfsetispeed(&newtio,B115200);
        cfsetospeed(&newtio,B115200);
        break;
    default:
        cfsetispeed(&newtio,B9600);
        cfsetospeed(&newtio,B9600);
        break;
    }

    if(nStop == 1)
        newtio.c_cflag &= ~CSTOPB;
    else if(nStop == 2)
        newtio.c_cflag |= CSTOPB;

    newtio.c_cc[VTIME] = 0;
    newtio.c_cc[VMIN]  = 0;
    tcflush(confd,TCIFLUSH);

    if((tcsetattr(confd,TCSANOW,&newtio))!=0)
    {
        perror("com set error");
        return -1;
    }
    printf("set done!");
    return 0;
}

//the specific uart device name should be confirmed by the following commands:
//*
//  $ ls /sys/bus/pci/devices/0000\:00\:18.?/dw-apb-uart.*/tty/ | grep tty
//  /sys/bus/pci/devices/0000:00:18.0/dw-apb-uart.8/tty/:
//  ttyS4
//  /sys/bus/pci/devices/0000:00:18.1/dw-apb-uart.9/tty/:
//  ttyS5
int onBoardUART::openPort()
{
    int fd;
    fd=open("/dev/ttyS5",O_RDWR|O_NOCTTY|O_NDELAY);
    if(fd==-1)
    {
        perror("Cannot open serial port!");
        return -1;
    }
    else
        printf("open ttyS5 successfully");

    if(fcntl(fd,F_SETFL,0)<0)
        perror("fcntl failed!");
    else
        printf("fcntl = %d",fcntl(fd,F_SETFL,0));

    if(isatty(STDIN_FILENO)==0)
        perror("standard input is not a terminal device");
    else
        printf("isatty success!");

    return fd;
}

void onBoardUART::sendData(int length)
{
    write(confd,sendBuff,length);
}

//@param: recvBuff, the data that read
//@return:
//  the length of data that read. 0 represents read nothing.
int onBoardUART::receiveData()
{
    int nread = read(confd,recvBuff,1024);
    return nread;
}

onBoardUART::onBoardUART(int nSpeed,int nBits,char nEvent,int nStop)
{
    if((confd = openPort()) == -1)
        exit(-1);
    if(setOption(nSpeed,nBits,nEvent,nStop))
        exit(-1);
    
    sendBuff = new char[1024];
    recvBuff = new char[1024];
}

onBoardUART::~onBoardUART()
{
    close(confd);
    delete []sendBuff;
    delete []recvBuff;
}
//END class onBoardUART define
//-------------------------------------------------------



//class onBoardPWM define
//--------------------------------------------------------
int onBoardPWM::__export()
{
    char buffer[64];  
    int len;  
    int fd;  

    fd = open("/sys/class/pwm/pwmchip0/export", O_WRONLY);

    if (fd < 0)
    {  
        printf("Failed to open export for writing!\n");
        return(-1);  
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", pwmNum);  
    if (write(fd, buffer, len) < 0)
    {  
        printf("Failed to export pwm%d!\n",pwmNum);  
        return -1;  
    }

    close(fd);
    return 0;
}

int onBoardPWM::__unexport()
{
    char buffer[64];
    int len;
    int fd;

    fd = open("/sys/class/pwm/pwmchip0/unexport", O_WRONLY);

    if (fd < 0)
    {
        printf("Failed to open unexport for writing!\n");
        return -1;
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", pwmNum);
    if (write(fd, buffer, len) < 0)
    {
        printf("Failed to unexport pwm%d!\n",pwmNum);
        return -1;
    }  

    close(fd);
    return 0;
}

int onBoardPWM::__enable()
{
    char buffer[64];
    int len;
    int fd;

    snprintf(buffer, sizeof(buffer), "/sys/class/pwm/pwmchip0/pwm%d/enable", pwmNum);
    fd = open(buffer, O_WRONLY);

    if (fd < 0)
    {
        printf("Failed to open enable file!\n");
        return -1;
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", 1);
    if (write(fd, buffer, len) < 0)
    {
        printf("Failed to enable pwm%d!\n",pwmNum);
        return -1;
    }

    close(fd);
    return 0;
}

//@param: period in ns (10^-9s)
void onBoardPWM::setPeriod(int period)
{
    char buffer[64];
    int len;
    int fd;

    snprintf(buffer, sizeof(buffer), "/sys/class/pwm/pwmchip0/pwm%d/period", pwmNum);
    fd = open(buffer, O_WRONLY);

    if (fd < 0)
    {
        printf("Failed to open set period file!\n");
        return;
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", period);
    if (write(fd, buffer, len) < 0)
    {
        printf("Failed to set period for pwm%d!\n",pwmNum);
        return;
    }  

    close(fd);
}

//@param: DutyCircle in ns (10^-9s)
void onBoardPWM::setDutyCircle(int duty_circle)
{
    char buffer[64];
    int len;
    int fd;

    snprintf(buffer, sizeof(buffer), "/sys/class/pwm/pwmchip0/pwm%d/duty_cycle", pwmNum);
    fd = open(buffer, O_WRONLY);

    if (fd < 0)
    {
        printf("Failed to open set duty cycle file!\n");
        return;
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", duty_circle);
    if (write(fd, buffer, len) < 0)
    {
        printf("Failed to set duty cycle for pwm%d!\n",pwmNum);
        return;
    }  

    close(fd);
}

onBoardPWM::onBoardPWM(onBoardPin::pwmType pwm_sel,int period,int duty_cycle)
{
    pwmNum = (int)pwm_sel;
    __export();
    setPeriod(period);
    setDutyCircle(duty_cycle);
    __enable();
}

onBoardPWM::~onBoardPWM()
{
    __unexport();
}















