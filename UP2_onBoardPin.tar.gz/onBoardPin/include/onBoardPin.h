/* ************************************************
 * This file is the header of onBoardPin.cpp
 * @Auther : Derek Lai
 * @Date   : 2018/4/1
 * @Device : UP2 Squared
 * ***********************************************/
#ifndef __ONBOARDPIN__H_
#define __ONBOARDPIN__H_

namespace onBoardPin
{
    //diretion define
    const int IN = 0;
    const int OUT = 1;

    //edge define
    const int NOT_INTERRUPT = 0;
    const int RISING        = 1;
    const int FALLING       = 2;
    const int BOTH          = 3;
    
    enum pwmType
    {
        PWM0 = 0,
        PWM1 = 1,
        PWM3 = 3
    };
}

class onBoardGPIO
{
  private:
    int pinNum;
    int __export();
    int __unexport();
    int setDirection(int direction);

  public:
    onBoardGPIO(int pinNumber, int direction);
    ~onBoardGPIO();
    int setEdge(int edge);
    int writeValue(int value);
    int readValue();

};

class onBoardUART
{
  private:
    int confd;
    int setOption(int nSpeed,int nBits,char nEvent,int nStop);
    int openPort();
  
  public:
    char *sendBuff;
    char *recvBuff;

    void sendData(int length);
    int receiveData();
    onBoardUART(int nSpeed,int nBits,char nEvent,int nStop);
    ~onBoardUART();
};

class onBoardPWM
{
  private:
    int pwmNum;
    int __export();
    int __unexport();
    int __enable();

  public:
    void setPeriod(int period);
    void setDutyCircle(int duty_circle);
    onBoardPWM(onBoardPin::pwmType pwm_sel,int period,int duty_cycle);
    ~onBoardPWM();
};




#endif

