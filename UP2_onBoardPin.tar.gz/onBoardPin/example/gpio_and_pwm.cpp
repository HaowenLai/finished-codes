#include "onBoardPin.h"
#include <stdio.h>
#include <unistd.h>

int main()
{
    //onBoardGPIO gpio328(328,onBoardPin::OUT);
    //onBoardUART uart1(9600,8,'N',1);
    //sprintf(uart1.sendBuff,"%c%c",'a','q');
    
    //这是普通io口使用和串口使用示例程序
    //while(1)
    //{
    //   gpio328.writeValue(1);
    //    usleep(500000);
    //    gpio328.writeValue(0);
    //    usleep(500000);
    //    
    //    uart1.sendData(2);
    //}
    
    
    //这个是使用PWM实现呼吸灯的示例程序
    int i = 0;
    int flag = 1;
    int duty;
    onBoardPWM pwm0(onBoardPin::PWM0,15000000,100);
    onBoardPWM pwm3(onBoardPin::PWM3,15000000,100);
    while(1)
    {
        duty = i*300000;
        
        if(i == 30)
           flag = -
            flag = 1;
        
        i += flag;
        pwm0.setDutyCircle(duty);
        pwm3.setDutyCircle(duty);
        usleep(50000);
    }
    return 0;
}
