/**
 *                             _ooOoo_
 *                            o8888888o
 *                            88" . "88
 *                            (| -_- |)
 *                            O\  =  /O
 *                         ____/`---'\____
 *                       .'  \\|     |//  `.
 *                      /  \\|||  :  |||//  \
 *                     /  _||||| -:- |||||-  \
 *                     |   | \\\  -  /// |   |
 *                     | \_|  ''\---/''  |   |
 *                     \  .-\__  `-`  ___/-. /
 *                   ___`. .'  /--.--\  `. . __
 *                ."" '<  `.___\_<|>_/___.'  >'"".
 *               | | :  `- \`.;`\ _ /`;.`/ - ` : | |
 *               \  \ `-.   \_ __\ /__ _/   .-` /  /
 *          ======`-.____`-.___\_____/___.-`____.-'======
 *                             `=---='
 *          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 *                      佛祖保佑        永无BUG
 **/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>

//diretion define
#define IN  0
#define OUT 1

//函数声明
static int gpio_export(int pin);
static int gpio_unexport(int pin);
static int gpio_direction(int pin, int dir);
static int gpio_write(int pin, int value);
static int gpio_read(int pin);

static int gpio_export(int pin)  
{  
    char buffer[64];  
    int len;  
    int fd;  

    fd = open("/sys/class/gpio/export", O_WRONLY);  

    if (fd < 0)
    {  
        printf("Failed to open export for writing!\n");
        return(-1);  
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", pin);  
    if (write(fd, buffer, len) < 0)
    {  
        printf("Failed to export gpio%d!\n",pin);  
        return -1;  
    }

    close(fd);
    return 0;  
}  


static int gpio_unexport(int pin)  
{  
    char buffer[64];  
    int len;  
    int fd;  

    fd = open("/sys/class/gpio/unexport", O_WRONLY);  

    if (fd < 0) 
    {
        printf("Failed to open unexport for writing!\n");  
        return -1;  
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", pin);  
    if (write(fd, buffer, len) < 0) 
    {
        printf("Failed to unexport gpio%d!\n",pin);  
        return -1;  
    }  

    close(fd);  
    return 0;  
} 

//dir: 0-->IN, 1-->OUT
static int gpio_direction(int pin, int dir)  
{  
    static const char dir_str[] = "in\0out";  
    char path[64];  
    int fd;  

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/direction", pin);  
    fd = open(path, O_WRONLY);  

    if (fd < 0) 
    {
        printf("Failed to open gpio%d direction for writing!\n",pin);  
        return -1;  
    }  

    if (write(fd, &dir_str[dir == 0 ? 0 : 3], dir == 0 ? 2 : 3) < 0) 
    {
        printf("Failed to set direction for pin%d!\n",pin);  
        return -1;  
    }  

    close(fd);  
    return 0;  
}  

//value: 0-->LOW, 1-->HIGH
static int gpio_write(int pin, int value)  
{  
    static const char values_str[] = "01";  
    char path[64];  
    int fd;  

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", pin);  
    fd = open(path, O_WRONLY);  

    if (fd < 0) 
    {
        printf("Failed to open gpio%d value for writing!\n",pin);  
        return -1;  
    }  

    if (write(fd, &values_str[value == 0 ? 0 : 1], 1) < 0) 
    {
        printf("Failed to write value for pin %d!\n",pin);  
        return -1;  
    }  

    close(fd);  
    return 0;  
}

static int gpio_read(int pin)
{  
    char path[64];  
    char value_str[3];  
    int fd;  

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", pin);  

    fd = open(path, O_RDONLY);  

    if (fd < 0) 
    {
        printf("Failed to open gpio%d value for reading!\n",pin);  
        return -1;  
    }  

    if (read(fd, value_str, 3) < 0)
    {
        printf("Failed to read value for pin %d!\n",pin);  
        return -1;  
    }  

    close(fd);  

    return (atoi(value_str));
}  


// none表示引脚为输入，不是中断引脚
// rising表示引脚为中断输入，上升沿触发
// falling表示引脚为中断输入，下降沿触发
// both表示引脚为中断输入，边沿触发
// 0-->none, 1-->rising, 2-->falling, 3-->both
static int gpio_edge(int pin, int edge)
{
    const char dir_str[] = "none\0rising\0falling\0both"; 
    char ptr;
    char path[64];  
    int fd; 

    switch(edge)
    {
    case 0:
        ptr = 0;
        break;
    case 1:
        ptr = 5;
    break;
    case 2:
        ptr = 12;
        break;
    case 3:
        ptr = 20;
        break;
    default:
        ptr = 0;
    } 

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/edge", pin);  

    fd = open(path, O_WRONLY);  

    if (fd < 0) 
    {  
        printf("Failed to open gpio%d edge for writing!\n",pin);  
        return -1;  
    }  

    if (write(fd, &dir_str[ptr], strlen(&dir_str[ptr])) < 0) 
    {
        printf("Failed to set edge for pin %d!\n",pin);  
        return -1;  
    }  

    close(fd);  

    return 0;  
}

/*
//GPIO1_17
int main()  
{  
    int gpio_fd, ret;
    struct pollfd fds[1];
    char buff[10];
    unsigned char cnt = 0;

    //LED引脚初始化
    gpio_export(328);
    gpio_direction(328, OUT);
    gpio_write(328, 0);
    printf("LED init successfully");
    
    //按键引脚初始化
    gpio_export(403);
    gpio_direction(403, IN);
    gpio_edge(403,1);
    gpio_fd = open("/sys/class/gpio/gpio403/value",O_RDONLY);

    if(gpio_fd < 0)
    {
        printf("@Failed to open value!\n");  
        return -1;  
    }

    fds[0].fd = gpio_fd;
    fds[0].events  = POLLPRI;

    ret = read(gpio_fd,buff,10);

    if( ret == -1 )
        printf("@read\n");

    while(1)
    {
        ret = poll(fds,1,0);

        if( ret == -1 )
            printf("@poll\n");

        if( fds[0].revents & POLLPRI)
        {
            ret = lseek(gpio_fd,0,SEEK_SET);

            if( ret == -1 )
                printf("@lseek\n");

            ret = read(gpio_fd,buff,10);

            if( ret == -1 )
                printf("@read\n");

            gpio_write(328, cnt++%2);

        }
        usleep(100000);
    }

    return 0;
}
*/

int main()
{
    //LED引脚初始化
    int pin_num = 328;
    int delayUs = 50000;
    gpio_export(pin_num);
    gpio_direction(pin_num, OUT);
    
    //按键引脚初始化
    int btn_num = 403;
    gpio_export(btn_num);
    gpio_direction(btn_num, IN);
    gpio_edge(btn_num,1);
    
    int led_status = 0;
    int readResult = 0;
    while(1)
    {
        readResult = gpio_read(btn_num);
        //printf("%d\n",readResult);
        if(readResult)
        {
            gpio_write(pin_num,led_status);
            led_status = !led_status;
        }
        usleep(100000);
    }
    
    return 0;
}





