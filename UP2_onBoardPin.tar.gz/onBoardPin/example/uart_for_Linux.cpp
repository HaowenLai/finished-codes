#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <string.h>
#include <iostream>
#include <math.h>

using namespace std;

int set_opt(int fd,int nSpeed,int nBits,char nEvent,int nStop)
{
    struct termios newtio,oldtio;
    if(tcgetattr(fd,&oldtio) != 0)
    {
        perror("SetupSerial 1");
        return -1;
    }
    bzero(&newtio,sizeof(newtio));
    newtio.c_cflag |= CLOCAL|CREAD;
    newtio.c_cflag &= ~CSIZE;

    switch(nBits)
    {
    case 7:
        newtio.c_cflag |=CS7;
        break;
    case 8:
        newtio.c_cflag |=CS8;
        break;
    }

    switch(nEvent)
    {
    case 'O':
        newtio.c_cflag |= PARENB;
        newtio.c_cflag |= PARODD;
        newtio.c_iflag |= (INPCK|ISTRIP);
        break;
    case 'E':
        newtio.c_cflag |= PARENB;
        newtio.c_cflag &= ~PARODD;
        newtio.c_iflag |= (INPCK|ISTRIP);
        break;
    case 'N':
        newtio.c_cflag &= ~PARENB;
        break;
    }

    switch(nSpeed)
    {
    case 2400:
        cfsetispeed(&newtio,B2400);
        cfsetospeed(&newtio,B2400);
        break;
    case 4800:
        cfsetispeed(&newtio,B4800);
        cfsetospeed(&newtio,B4800);
        break;
    case 9600:
        cfsetispeed(&newtio,B9600);
        cfsetospeed(&newtio,B9600);
        break;
    case 115200:
        cfsetispeed(&newtio,B115200);
        cfsetospeed(&newtio,B115200);
        break;
    default:
        cfsetispeed(&newtio,B9600);
        cfsetospeed(&newtio,B9600);
        break;
    }

    if(nStop == 1)
        newtio.c_cflag &= ~CSTOPB;
    else if(nStop == 2)
        newtio.c_cflag |= CSTOPB;

    newtio.c_cc[VTIME] = 0;
    newtio.c_cc[VMIN]  = 0;
    tcflush(fd,TCIFLUSH);

    if((tcsetattr(fd,TCSANOW,&newtio))!=0)
    {
        perror("com set error");
        return -1;
    }
    cout<<"set done!"<<endl;
    return 0;
}

int open_port()
{
    int fd;
    fd=open("/dev/ttyS5",O_RDWR|O_NOCTTY|O_NDELAY);
    if(fd==-1)
    {
        perror("Cannot open serial port!");
        return -1;
    }
    else
        cout<<"open ttyAMA0"<<endl;

    if(fcntl(fd,F_SETFL,0)<0)
        cout<<"fcntl failed!"<<endl;
    else
        cout<<"fcntl="<<fcntl(fd,F_SETFL,0)<<endl;

    if(isatty(STDIN_FILENO)==0)
        cout<<"standard input is not a terminal device"<<endl;
    else
        cout<<"isatty success!"<<endl;

    cout<<"fd_open="<<fd<<endl;
    return fd;
}

int main()
{
    int fd;
    int i,nread;
    char buff[512];
    char sbuf[512];

    //char column='0';
    int col=0;

    if((fd=open_port())<0)
    {
        perror("open_port error");
        return -1;
    }
    if((i=set_opt(fd,9600,8,'N',1))<0)
    {
        perror("set_opt error");
        return -1;
    }
    cout<<"fd="<<fd<<endl;


    while(1)
    {
        cin>>col;
       // column+=col;
        sprintf(sbuf,"%c%c%c%c",0xbb,0x03,(char)(col & 0xff),0xff);
        write(fd,sbuf,4);

        if((nread=read(fd,buff,512))>0)
        {
            cout<<"nread="<<nread<<endl;
            buff[nread]='\0';
            cout<<buff<<endl;
            //write(fd,"Roger that!",12);
        }

    }

/*
    while(1)
    {
        if((nread=read(fd,buff,512))>0)
        {
            //cout<<"nread="<<nread<<endl;
            //buff[nread]='\0';
            cout<<buff<<endl;
            write(fd,"Roger that!",12);
        }

    }
*/



    return 0;
}
