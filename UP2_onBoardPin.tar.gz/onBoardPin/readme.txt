//@Auther : Derek Lai
//@Date   : 2018/4/2

这是up2 squared 嵌入式板子针角的驱动，封装在类里面了
onBoardPin.cpp是这个类的实现
其他的文件是一些示例程序

功能有GPIO，UART，PWM
